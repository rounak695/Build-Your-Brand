# Design System: Cinematic Precision

## 1. Overview & Creative North Star
**The Creative North Star: "The Obsidian Gallery"**

This design system is not a utility; it is a stage. It rejects the "SaaS-standard" look of heavy borders and neon accents in favor of a cinematic, high-fidelity environment where content is the protagonist. We move beyond the grid by embracing **intentional atmospheric depth**. By utilizing a "Pitch Black" foundation and "Deep Maroon" accents, we create a workspace that feels like a darkened studio—focused, expensive, and professional.

To break the "template" feel, this system relies on **Tonal Layering** and **Asymmetric Breathing Room**. We do not use lines to separate ideas; we use the absence of light and the subtle shift of surface values to guide the eye.

---

## 2. Colors & Surface Philosophy

The palette is anchored in deep shadows and surgical strikes of color. We utilize a Material-inspired token set, but apply it with editorial restraint.

### The Palette
*   **Background:** `#0B0B0B` (Pitch Black) – The infinite canvas.
*   **Primary (Accent):** `#5A0F1C` (Deep Maroon) – Used for high-intent actions and "hero" moments.
*   **Secondary/Neutral:** `#A0A0A0` – For metadata and secondary hierarchy.
*   **On-Surface:** `#FFFFFF` – High-contrast clarity for primary reading.

### The "No-Line" Rule
**Standard 1px borders are strictly prohibited for sectioning.** 
Structural boundaries must be defined solely through:
1.  **Background Shifts:** Placing a `surface_container_low` element against a `surface` background.
2.  **Negative Space:** Using the Spacing Scale (specifically `8` to `16`) to create a "gutter" of darkness between functional areas.

### Surface Hierarchy & Nesting
Treat the UI as a series of nested obsidian plates. Use the following hierarchy to move "closer" to the user:
*   **Canvas/Backdrop:** `surface_container_lowest` (#0E0E0E)
*   **Standard Panels:** `surface` (#131313)
*   **Floating Modals/Popovers:** `surface_bright` (#3A3939)

### The "Glass & Gradient" Rule
To add "soul" to the dark mode, use **Backdrop Blurs** (20px–40px) on floating elements like toolbars and context menus. 
*   **Signature Texture:** Main CTAs should not be flat maroon. Apply a subtle linear gradient from `primary` (#FFB2B6) to `primary_container` (#5A0F1C) at a 135° angle to create a metallic, silk-like sheen.

---

## 3. Typography: The Editorial Voice

We utilize a dual-typeface system to balance high-end brand authority with technical legibility.

*   **Display & Headlines (Manrope):** Use for large-scale titles and section headers. Its geometric structure provides the "architectural" feel required for a creative tool.
*   **Body & UI (Inter):** The workhorse. Inter’s tall x-height ensures that even at `body-sm` (0.75rem), the tool remains accessible during long creative sessions.

**Hierarchy Guidance:**
*   **Display-LG (3.5rem):** Reserved for "Hero" states or empty-state moments.
*   **Label-MD/SM:** Used for all button text and metadata. These must always be in **Uppercase** with a +5% letter-spacing to enhance the premium feel.

---

## 4. Elevation & Depth

We avoid the "card-on-gray" look. Depth is atmospheric, not structural.

### The Layering Principle
Stacking defines priority. A side panel might be `surface_container_low`, while the workspace is `surface`. The contrast is barely perceptible, requiring a high-quality display—matching the hardware of our professional user base.

### Ambient Shadows
Shadows are never black. They are a "glow of darkness."
*   **Token:** 0px 12px 32px rgba(0, 0, 0, 0.4).
*   For floating Primary elements, use a tinted shadow: `rgba(90, 15, 28, 0.2)` to create a subtle maroon "under-glow."

### The "Ghost Border" Fallback
If contrast is legally required for accessibility, use a **Ghost Border**: 
*   `outline_variant` (#554243) at **15% Opacity**. It should feel like a catch-light on the edge of a piece of glass, not a stroke.

---

## 5. Components

### Buttons (The "Jewel" Approach)
*   **Primary:** Deep Maroon gradient, 12px (`md`) rounded corners. No border. Text is `on_primary_fixed` (#40000D).
*   **Secondary:** Glassmorphic. `surface_bright` at 10% opacity with a 20px backdrop blur. 
*   **Tertiary:** Pure text with a geometric "chevron" icon (0.5px stroke).

### Input Fields (The "Inscribed" Approach)
*   Do not use boxes. Use a `surface_container_highest` background with a bottom-only Ghost Border. 
*   **Active State:** The border transitions to a 1px solid `primary` (#FFB2B6) to simulate a "lit" edge.

### Cards & Lists (The "Breath" Approach)
*   **Forbid Dividers:** Separation is achieved via `spacing-6` (1.5rem) gaps. 
*   **Interaction:** On hover, a card should shift from `surface` to `surface_bright` with a 200ms ease-in-out transition.

### Custom Component: The "Precision HUD"
For creative tools, use a "Heads Up Display" for property inspectors. These are floating, semi-transparent panels (`surface_container_lowest` at 80% opacity) with 16px (`lg`) corner radius and a 40px backdrop blur.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use asymmetry. Place a primary action off-center or use varying column widths to create a "custom-built" feel.
*   **DO** use "Thin" icon weights (1px or 0.5px). Heavy icons break the cinematic elegance.
*   **DO** embrace the "Pitch Black." Let the #0B0B0B background breathe; negative space is a luxury feature.

### Don't
*   **DON’T** use pure white (#FFFFFF) for long-form body text. Use `secondary` (#A0A0A0) to reduce eye strain in dark environments.
*   **DON’T** use standard Material/FontAwesome icons. If a bespoke icon is unavailable, use minimalist geometric primitives (dots, thin slashes, open circles).
*   **DON’T** use "Drop Shadows" on flat-on-flat surfaces. If the container doesn't "float" (like a menu), it doesn't get a shadow.